-- Hands on the Wheel (HOTW)
-- Copyright (c) 2026 1Matzh. All rights reserved.
-- Written permission from 1Matzh is required. See LICENSE or hotw/code-license.txt.
-- RSA-2048 / PKCS#1 v1.5 SHA-256 verification. Only public arithmetic is used.
local M={};local B=65536
local function limbs(hex)
 local out={};for i=#hex,1,-4 do out[#out+1]=tonumber(hex:sub(math.max(1,i-3),i),16)end;return out
end
local function ge(a,b)
 for i=#b,1,-1 do if a[i]~=b[i]then return a[i]>b[i]end end;return true
end
local function add(a,b,n)
 local r,c={},0
 for i=1,#n do local v=a[i]+b[i]+c;r[i]=v%B;c=math.floor(v/B)end
 if c>0 or ge(r,n)then
  local borrow=0
  for i=1,#n do local v=r[i]-n[i]-borrow;if v<0 then v=v+B;borrow=1 else borrow=0 end;r[i]=v end
 end
 return r
end
local function multiply(a,b,n)
 local r={};for i=1,#n do r[i]=0 end
 for i=1,#n do
  local v=b[i]
  for _=1,16 do
   if v%2==1 then r=add(r,a,n)end
   v=math.floor(v/2);a=add(a,a,n)
  end
 end
 return r
end
function M.verify(message,signature,key)
 if type(message)~='string'or type(signature)~='string'or#signature~=512 or not signature:match('^[0-9a-f]+$')or type(key)~='table'or key.exponent~=65537 or type(key.modulus)~='string'or#key.modulus~=512 or not key.modulus:match('^[0-9a-f]+$')then return false end
 local n,s=limbs(key.modulus),limbs(signature);if ge(s,n)then return false end
 local result=s
 for _=1,16 do result=multiply(result,result,n)end
 result=multiply(result,s,n)
 local hex={};for i=#n,1,-1 do hex[#hex+1]=string.format('%04x',result[i])end
 local digest=hashStringSHA256(message):lower()
 local expected='0001'..string.rep('ff',202)..'00'..'3031300d060960864801650304020105000420'..digest
 return table.concat(hex)==expected
end
return M
