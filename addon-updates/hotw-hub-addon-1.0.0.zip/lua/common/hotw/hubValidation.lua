-- Hands on the Wheel (HOTW)
-- Copyright (c) 2026 1Matzh. All rights reserved.
-- Unauthorized copying, modification, redistribution, reuse or sale is prohibited.
-- Written permission from 1Matzh is required. See LICENSE or hotw/code-license.txt.
-- The game validates downloaded data independently of the browser.
local M={maxFile=80*1024*1024,maxCharacter=220*1024*1024,maxFiles=162}
local function texture(path)
 return type(path)=='string'and not path:find('..',1,true)and
  (path:match('^textures/[a-zA-Z0-9_.%-]+%.png$')or path:match('^textures/[a-zA-Z0-9_.%-]+%.dds$')or
   path:match('^pbr/[a-zA-Z0-9_.%-]+%.png$')or path:match('^pbr/[a-zA-Z0-9_.%-]+%.dds$'))
end
function M.model(model,id)
 assert(type(model)=='string'and#model>0 and#model<=M.maxFile,'Invalid character model size.')
 assert(not model:upper():find('<!DOCTYPE',1,true)and not model:upper():find('<!ENTITY',1,true),'External XML declaration rejected.')
 local prefix='/hotw/characters/'..id..'/'
 local stack,roots,nodes={},0,0
 local parser=require('libs/slaxml/slaxml'):parser{
  startElement=function(name,namespace)
   nodes=nodes+1;assert(nodes<=1000000 and#stack<128,'Character model is too complex.')
   if#stack==0 then
    roots=roots+1;assert(roots==1 and name=='COLLADA'and type(namespace)=='string'and namespace:match('/COLLADASchema$'),'Invalid Collada root.')
   end
   stack[#stack+1]=name
  end,
  attribute=function(name,value)
   if name=='url'or name=='source'or(name=='target'and(stack[#stack]or''):match('^instance_'))then
    assert(value:sub(1,1)=='#','External model reference rejected.')
   end
  end,
  text=function(value)
   if stack[#stack]=='init_from'then
    value=value:match('^%s*(.-)%s*$')
    assert(texture(value)or(value:sub(1,#prefix)==prefix and texture(value:sub(#prefix+1)))or value:match('^[a-zA-Z_][a-zA-Z0-9_%-]*$'),'External model texture rejected.')
   elseif#stack==0 then assert(not value:find('%S'),'Text outside the model root.')end
  end,
  closeElement=function(name)assert(stack[#stack]==name,'Unbalanced character model.');stack[#stack]=nil end,
  pi=function(name)assert(name=='xml'and roots==0,'Unsupported XML instruction.')end
 }
 parser:parse(model,{stripWhitespace=true})
 assert(roots==1 and#stack==0,'Incomplete character model.')
end
function M.metadata(name,data,id)
 assert(type(data)=='table','Invalid character metadata.')
 if name=='colors.json'then
  assert(#data<=128,'Too many character color entries.')
  local prefix='/hotw/characters/'..id..'/'
  local namespace='^hotw_character_'..id:gsub('%-','_')..'_[a-zA-Z0-9_]+$'
  for _,color in pairs(data)do
   assert(type(color)=='table'and type(color.material)=='string'and color.material:match(namespace)and
    (color.field=='baseColorMap'or color.field=='diffuseMap')and(color.group=='skin'or color.group=='clothing'),'Invalid character color binding.')
   for _,key in ipairs({'map','source'})do
    local value=color[key];assert(type(value)=='string'and value:sub(1,#prefix)==prefix and texture(value:sub(#prefix+1)),'External color texture rejected.')
   end
  end
 elseif name=='fullbody.json'then assert(type(data.meshes)=='table'and data.skeletonProfile=='hotw-humanoid-v4'and data.boneCount==74,'Character must use the shared HOTW humanoid skeleton.')
 elseif name=='feet.json'then assert(type(data.contacts)=='table','Missing character foot metadata.')end
end
M.texture=texture
return M
