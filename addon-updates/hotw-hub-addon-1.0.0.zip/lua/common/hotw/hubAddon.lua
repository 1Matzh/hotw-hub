-- Hands on the Wheel (HOTW)
-- Copyright (c) 2026 1Matzh. All rights reserved.
-- Unauthorized copying, modification, redistribution, reuse or sale is prohibited.
-- Written permission from 1Matzh is required. See LICENSE or hotw/code-license.txt.
local M={}
local bridge=require('hotw/hubBridge')
function M.open()
  local ok,session=pcall(bridge.start)
  if not ok then return {success=false,opened=false,message='Could not connect HOTW Hub to BeamNG.drive.'}end
  local called,opened=false,false
  if type(openWebBrowser)=='function'then called,opened=pcall(openWebBrowser,session.url)end
  return {success=true,opened=called and opened==true,url=session.url:match('^[^#]+')}
end
function M.copyLink()
  local ok=pcall(function()assert(type(setClipboard)=='function');setClipboard(bridge.start().url)end)
  return {success=ok,message=ok and 'HOTW Hub link copied. Keep BeamNG.drive open.'or'Could not copy the HOTW Hub link.'}
end
function M.stop()bridge.stop()end
function M.step()bridge.step()end
return M
