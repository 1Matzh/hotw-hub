-- Hands on the Wheel (HOTW)
-- Copyright (c) 2026 1Matzh. All rights reserved.
-- Unauthorized copying, modification, redistribution, reuse or sale is prohibited.
-- Written permission from 1Matzh is required. See LICENSE or hotw/code-license.txt.
-- A session-scoped loopback file bridge. Never accepts Lua, shell commands,
-- arbitrary roots, arbitrary origins, or executable files.
local M={}
local validation=require('hotw/hubValidation')
local credits=require('hotw/characterCredits')
local updater=require('hotw/hubUpdater')
local listener,token,port,lastRequest,socket
local clients={}
local created={}
local origin,website
local root='/hotw/'
local static={['index.html']='text/html; charset=utf-8',['hub.js']='text/javascript; charset=utf-8',
 ['hub.css']='text/css; charset=utf-8',['web-library.js']='text/javascript; charset=utf-8',
 ['game-files.js']='text/javascript; charset=utf-8',['credits.js']='text/javascript; charset=utf-8',['addon-update.js']='text/javascript; charset=utf-8',['addon-version.json']='application/json; charset=utf-8',['update-key.json']='application/json; charset=utf-8',['languages.json']='application/json; charset=utf-8',
 ['app_icon.png']='image/png',['InterVariable.woff2']='font/woff2',['Inter-OFL.txt']='text/plain; charset=utf-8',['LICENSE']='text/plain; charset=utf-8'}
local policy="default-src 'self'; connect-src 'self' https://raw.githubusercontent.com https://api.github.com; img-src 'self' data: blob:; font-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"
local required={['character.json']=true,['fullbody.xml']=true,['fullbody.json']=true,['feet.json']=true,
 ['materials.json']=true,['colors.json']=true,['thumbnail.png']=true,['hotw-installed.json']=true,['hotw-pending.json']=true}
local function slug(s)return type(s)=='string'and#s>0 and#s<=40 and s:match('^[a-z0-9][a-z0-9_%-]*$')and s~='default'end
local function asset(s)return required[s]or s:match('^textures/[a-zA-Z0-9_.%-]+%.png$')or s:match('^textures/[a-zA-Z0-9_.%-]+%.dds$')or s:match('^pbr/[a-zA-Z0-9_.%-]+%.png$')or s:match('^pbr/[a-zA-Z0-9_.%-]+%.dds$')end
local function allowed(path,directory)
 if type(path)~='string'or#path>200 or path:find('..',1,true)or path:find('[^a-zA-Z0-9_./%-]')then return false end
 if directory and(path==''or path=='characters'or path=='hub-transactions')then return true end
 if not directory and path=='characters-changed.json'then return true end
 local id,tail=path:match('^characters/([^/]+)/(.*)$')
 if not id then id=path:match('^characters/([^/]+)$');if id then return directory and slug(id)end end
 if id then return slug(id)and(directory and(tail=='textures'or tail=='pbr')or not directory and asset(tail))end
 local id,tail=path:match('^hub%-transactions/([^/]+)/(.*)$')
 if not id then id=path:match('^hub%-transactions/([^/]+)$');if id then return directory and slug(id)end end
 if id and slug(id)then
  if not directory and tail=='transaction.json'then return true end
  if directory and(tail=='backup'or tail=='backup/textures'or tail=='backup/pbr')then return true end
  local item=tail:match('^backup/(.+)$');return not directory and item and asset(item)
 end
 return false
end
local function cleanup(c)
 if c.file then c.file:close();c.file=nil end
 if c.operation and not c.updateComplete then updater.abortUpload(c.operation)end
 if c.temp then FS:removeFile(c.temp);c.temp=nil end
 c.peer:close()
end
local function mayChange(path)
 local id=path:match('^characters/([^/]+)')
 if not id then return end
 local folder=root..'characters/'..id..'/'
 if not FS:directoryExists(folder)or created[id]then return end
 local data=jsonReadFile(folder..'hotw-installed.json')
 if type(data)~='table'or data.schema~=1 or data.id~=id or type(data.files)~='table'then
  local p=jsonReadFile(folder..'hotw-pending.json')
  local journal=jsonReadFile(root..'hub-transactions/'..id..'/transaction.json')
  assert(type(p)=='table'and p.id==id and type(journal)=='table'and journal.id==id and journal.schema==1,'Local character folders cannot be changed by the Hub.')
  return
 end
 local owned={['hotw-installed.json']=true,['hotw-pending.json']=true}
 for _,name in ipairs(data.files)do assert(asset(name),'Invalid owned character file.');owned[name]=true end
 local journal=jsonReadFile(root..'hub-transactions/'..id..'/transaction.json')
 if type(journal)=='table'and journal.id==id and type(journal.allowed)=='table'then for _,name in ipairs(journal.allowed)do if asset(name)then owned[name]=true end end end
 for _,value in ipairs(FS:findFiles(folder,'*',-1,true,false)or{})do
  assert(owned[value:sub(#folder+1)],'The character folder contains files outside its manifest.')
 end
end
function M.stop()
 for _,c in ipairs(clients)do cleanup(c)end;clients={}
 if listener then listener:close()end
 listener,token,port,lastRequest,origin,website=nil,nil,nil,nil,nil,nil;created={}
end
local function respond(c,status,body,kind,length)
 local data=type(body)=='string'and body or jsonEncode(body or{})
 c.output='HTTP/1.1 '..status..'\r\nConnection: close\r\nCache-Control: no-store\r\nContent-Type: '..(kind or'application/json')..'\r\nContent-Length: '..tostring(length or#data)..'\r\n'
 c.output=c.output..'X-Content-Type-Options: nosniff\r\nReferrer-Policy: no-referrer\r\nCross-Origin-Resource-Policy: same-origin\r\nX-Frame-Options: DENY\r\nContent-Security-Policy: '..policy..'\r\n'
 if c.validOrigin then
  c.output=c.output..'Access-Control-Allow-Origin: '..origin..'\r\nVary: Origin\r\nAccess-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS\r\nAccess-Control-Allow-Headers: authorization, content-type\r\nAccess-Control-Max-Age: 600\r\n'
 end
 c.output=c.output..'\r\n'..(length and''or data);c.sent=1;c.responding=true
end
local function queryValue(uri,name)
 local value=uri:match('[?&]'..name..'=([^&]*)')or''
 return(value:gsub('%%(%x%x)',function(n)return string.char(tonumber(n,16))end))
end
local function inventory()
 local entries={};local folder=root..'characters/'
 for _,value in ipairs(FS:findFiles(folder,'*',0,true,true)or{})do
  local id=value:sub(1,#folder)==folder and value:sub(#folder+1):gsub('/$','')or nil
  if id and slug(id)and FS:directoryExists(folder..id)then
   local ok,item=pcall(function()
    local base=folder..id..'/'
    assert(not FS:fileExists(base..'hotw-pending.json'))
    local data=jsonReadFile(base..'character.json')
    assert(type(data)=='table'and data.id==id)
    assert(type(data.name)=='string'and#data.name>0 and#data.name<=100 and credits.authors(data),'Invalid character credit.')
    for _,name in ipairs({'character.json','fullbody.xml','fullbody.json','feet.json','materials.json','colors.json','thumbnail.png'})do assert(FS:fileExists(base..name))end
    local managed=FS:fileExists(base..'hotw-installed.json');local revision
    if managed then
     local manifest=jsonReadFile(base..'hotw-installed.json')
     assert(type(manifest)=='table'and manifest.schema==1 and manifest.id==id and type(manifest.files)=='table'and#manifest.files<=160)
     local owned={['hotw-installed.json']=true}
     for _,name in ipairs(manifest.files)do assert(asset(name));owned[name]=true end
     for _,name in ipairs({'character.json','fullbody.xml','fullbody.json','feet.json','materials.json','colors.json','thumbnail.png'})do assert(owned[name])end
     for _,path in ipairs(FS:findFiles(base,'*',-1,true,false)or{})do assert(owned[path:sub(#base+1)])end
     revision=type(manifest.revision)=='string'and manifest.revision or nil
    end
    return {id=id,name=data.name,author=data.author,authors=credits.authors(data),localCharacter=not managed,revision=revision}
   end)
   if ok then entries[#entries+1]=item end
  end
 end
 return {characters=entries}
end
local materialFields={Stages=true,alphaRef=true,alphaTest=true,castShadows=true,class=true,doubleSided=true,dynamicCubemap=true,mapTo=true,materialTag0=true,name=true,version=true}
local stageFields={ambientOcclusionMap=true,baseColorFactor=true,baseColorMap=true,diffuseColor=true,diffuseMap=true,emissiveFactor=true,emissiveIntensityNits=true,emissiveMap=true,metallicFactor=true,metallicMap=true,normalMap=true,normalMapStrength=true,opacityFactor=true,opacityMap=true,roughnessFactor=true,roughnessMap=true,specular=true,specularPower=true}
local function validateUpload(c)
 if c.preference then
  local data=jsonReadFile(c.temp);assert(type(data)=='table'and type(data.language)=='string','Invalid Hub preferences.')
  for key in pairs(data)do assert(key=='language','Unsupported Hub preference.')end
  local valid=data.language=='auto'
  for _,language in ipairs((jsonReadFile('/hotw/hub/languages.json')or{}).languages or{})do if language.value==data.language then valid=true end end
  assert(valid,'Unsupported Hub language.');return
 end
 local id,name=c.path:match('^/hotw/characters/([^/]+)/(.+)$')
 if not id then return end
 local prefix='/hotw/characters/'..id..'/'
 if name=='character.json'then
  local data=jsonReadFile(c.temp);assert(type(data)=='table'and data.id==id,'Invalid character metadata.')
  assert(type(data.name)=='string'and#data.name>0 and#data.name<=100 and credits.authors(data),'Invalid character credit.')
 elseif name=='materials.json'then
  local materials=jsonReadFile(c.temp);assert(type(materials)=='table'and next(materials),'Invalid character materials.')
  local count=0;local namespace='^hotw_character_'..id:gsub('%-','_')..'_[a-zA-Z0-9_]+$'
  for key,mat in pairs(materials)do
   count=count+1;assert(count<=128 and type(key)=='string'and key:match(namespace)and type(mat)=='table'and mat.class=='Material'and mat.name==key and mat.mapTo==key,'Invalid character material class or namespace.')
   for field in pairs(mat)do assert(materialFields[field],'Unsupported character material field.')end
   assert(type(mat.Stages)=='table'and#mat.Stages>0 and#mat.Stages<=4,'Invalid material stages.')
   for _,stage in ipairs(mat.Stages)do
    assert(type(stage)=='table','Invalid material stage.')
    for field,value in pairs(stage)do
     assert(stageFields[field],'Unsupported material stage field.')
     if field:sub(-3)=='Map'then assert(type(value)=='string'and value:sub(1,#prefix)==prefix and validation.texture(value:sub(#prefix+1)),'External material texture rejected.')end
    end
   end
  end
 elseif name=='fullbody.xml'then
  local f=assert(io.open(c.temp,'rb'));local model=f:read('*all');f:close()
  validation.model(model,id)
 elseif name=='colors.json'or name=='feet.json'or name=='fullbody.json'then
  validation.metadata(name,jsonReadFile(c.temp),id)
 elseif name=='hotw-installed.json'then
  local data=jsonReadFile(c.temp);assert(type(data)=='table'and data.schema==1 and data.id==id and type(data.files)=='table','Invalid installed character manifest.')
  for _,item in ipairs(data.files)do assert(asset(item),'Unsupported installed character file.')end
 end
end
local function quota(path,length)
 local folder=path:match('^(characters/[^/]+)/')or path:match('^(hub%-transactions/[^/]+/backup)/')
 if not folder then assert(length<=65536,'Metadata too large.');return end
 local prefix=root..folder..'/';local count,total=0,length
 for _,file in ipairs(FS:findFiles(prefix,'*',-1,true,false)or{})do
  if file~=root..path then
   count=count+1;assert(count<validation.maxFiles,'Too many character files.')
   local f=assert(io.open(file,'rb'));local size=f:seek('end');f:close();total=total+size
   assert(total<=validation.maxCharacter,'Character storage limit exceeded.')
  end
 end
 assert(total<=validation.maxCharacter,'Character storage limit exceeded.')
end
local function finishWrite(c)
 c.file:close();c.file=nil
 if c.addonManifest then
  local f=assert(io.open(c.temp,'rb'));local bytes=f:read('*a');f:close()
  local result=updater.acceptManifest(bytes,c.operation);FS:removeFile(c.temp);c.temp=nil;c.updateComplete=true
  respond(c,'200 OK',result);return
 elseif c.addonPayload then
  local result=updater.completePayload(c.temp,c.operation);c.temp=nil;c.updateComplete=true
  respond(c,'200 OK',result);return
 end
 validateUpload(c)
 if FS:renameFile(c.temp,c.path)~=0 then
  assert(FS:copyFile(c.temp,c.path)==0,'Could not write character file.')
  FS:removeFile(c.temp)
 end
 local id=c.path:match('^/hotw/characters/([^/]+)/hotw%-installed%.json$');if id then created[id]=nil end
 c.temp=nil;respond(c,'200 OK',{success=true})
end
local function headers(c)
 local cut=c.buffer:find('\r\n\r\n',1,true);if not cut then assert(#c.buffer<=16384,'Request headers too large.');return end
 assert(cut<=16384,'Request headers too large.')
 local text=c.buffer:sub(1,cut-1);c.buffer=c.buffer:sub(cut+4)
 local method,uri=text:match('^([A-Z]+) ([^ ]+) HTTP/1%.[01]');assert(method and#uri<=512,'Invalid request.')
 local h={};for line in text:gmatch('[^\r\n]+')do local name,value=line:match('^([^:]+):%s*(.-)%s*$');if name then name=name:lower();assert(not h[name],'Duplicate request header.');h[name]=value end end
 assert(h.host=='127.0.0.1:'..port,'Host rejected.')
 local endpoint=uri:match('^([^?]+)')
 if method=='GET'and(endpoint=='/'or endpoint:sub(1,5)=='/hub/')then
  assert(not h.origin or h.origin==origin,'Origin rejected.')
  local name=(endpoint=='/'or endpoint=='/hub/')and'index.html'or endpoint:sub(6)
  assert(static[name],'Unknown Hub asset.')
  c.file=assert(io.open('/hotw/hub/'..name,'rb'));local size=c.file:seek('end');c.file:seek('set')
  respond(c,'200 OK','',static[name],size);c.readingFile=true;return
 end
 c.validOrigin=h.origin==origin or(not h.origin and h['sec-fetch-site']=='same-origin')
 assert(c.validOrigin,'Origin rejected.')
 if method=='OPTIONS'then respond(c,'204 No Content','');return end
 assert(h.authorization=='Bearer '..token,'Session rejected.')
 lastRequest=socket.gettime()
 local path=queryValue(uri,'path')
 if endpoint=='/session'and method=='GET'then respond(c,'200 OK',{success=true,name='BeamNG.drive',protocol=1,capabilities={inventory=true,copy=true,addonUpdate=true}});return end
 if endpoint=='/addon-update'then
  assert(path==''and(method=='GET'or method=='POST'),'Invalid addon update request')
  assert(not h['transfer-encoding']and tonumber(h['content-length']or'0')==0,'Addon updates accept no browser-supplied data')
  respond(c,'200 OK',method=='POST'and updater.start()or updater.status());return
 end
 if endpoint=='/addon-update-cancel'and method=='POST'then
  assert(not h['transfer-encoding']and tonumber(h['content-length']or'0')==0,'Invalid cancellation request')
  respond(c,'200 OK',updater.abortUpload(path));return
 end
 if(endpoint=='/addon-update-manifest'or endpoint=='/addon-update-payload')and method=='PUT'then
  for _,other in ipairs(clients)do assert(other==c or not other.upload,'Another upload is in progress')end
  local length=tonumber(h['content-length']);assert(length and length>0 and length==math.floor(length)and not h['transfer-encoding'],'Invalid update transfer size')
  if endpoint=='/addon-update-manifest'then
   local status=updater.status();assert(status.state=='checking'and status.operation==path and length<=16384,'Invalid update manifest operation')
   local temp='/temp/hotw/hub-transfer/';assert(FS:directoryCreate(temp,true)~=false)
   c.temp=temp..Engine.generateUUID():gsub('[^a-zA-Z0-9]','')..'.tmp';c.addonManifest=true
  else c.temp=updater.uploadPath(length,path);c.addonPayload=true end
  c.operation=path;c.total=length;c.remaining=length;c.file=assert(io.open(c.temp,'wb'));c.upload=true;return
 end
 if endpoint=='/preferences'and method=='GET'then
  local saved=jsonReadFile('/hotw/hub-preferences.json')
  respond(c,'200 OK',{language=type(saved)=='table'and type(saved.language)=='string'and saved.language or'auto',gameLanguage=require('hotw/language').state('auto').locale});return
 end
 if endpoint=='/preferences'and method=='PUT'then path='hub-preferences.json';c.preference=true end
 if endpoint=='/inventory'and method=='GET'then respond(c,'200 OK',inventory());return end
 if endpoint=='/copy'and method=='POST'then
  local source=queryValue(uri,'from')
  assert(allowed(source,false)and allowed(path,false),'Character copy path rejected.')
  local sourceId,sourceName=source:match('^characters/([^/]+)/(.+)$')
  local targetId,targetName=path:match('^hub%-transactions/([^/]+)/backup/(.+)$')
  if not sourceId then
   sourceId,sourceName=source:match('^hub%-transactions/([^/]+)/backup/(.+)$')
   targetId,targetName=path:match('^characters/([^/]+)/(.+)$')
  end
  assert(sourceId and sourceId==targetId and sourceName==targetName,'Only the same character file may be backed up or restored.')
  mayChange(source);mayChange(path)
  local temp='/temp/hotw/hub-transfer/';FS:directoryCreate(temp,true)
  local original=assert(io.open(root..source,'rb'));local size=original:seek('end');original:close();quota(path,size)
  c.temp=temp..Engine.generateUUID():gsub('[^a-zA-Z0-9]','')..'.tmp';c.path=root..path
  assert(FS:copyFile(root..source,c.temp)==0,'Could not copy character file.')
  c.file=assert(io.open(c.temp,'rb'));finishWrite(c);return
 end
 local isDirectory=endpoint=='/directory'
 assert(c.preference or allowed(path,isDirectory or endpoint=='/list')or(endpoint=='/stat'and allowed(path,true)),'Character path rejected.')
 local full=root..path
 if method=='PUT'or method=='POST'or method=='DELETE'then mayChange(path)end
 if endpoint=='/stat'and method=='GET'then
  if FS:directoryExists(full)then respond(c,'200 OK',{kind='directory'})elseif FS:fileExists(full)then respond(c,'200 OK',{kind='file'})else respond(c,'404 Not Found',{error='NotFoundError'})end
 elseif endpoint=='/directory'and method=='POST'then
  local id=path:match('^characters/([^/]+)$')or path:match('^hub%-transactions/([^/]+)$')
  if id and not FS:directoryExists(full)then
   local parent=path:match('^([^/]+)/');assert(#(FS:findFiles(root..parent..'/','*',0,false,true)or{})<250,'Too many character directories.')
   if parent=='characters'then created[id]=true end
  end
  assert(FS:directoryCreate(full,true)~=false,'Could not create character directory.');respond(c,'200 OK',{success=true})
 elseif endpoint=='/list'and method=='GET'then
  assert(FS:directoryExists(full),'Character directory missing.')
  local items={};local prefix=full:gsub('/$','')..'/'
  for _,value in ipairs(FS:findFiles(prefix,'*',0,true,true)or{})do
   local name=value:sub(1,#prefix)==prefix and value:sub(#prefix+1):gsub('/$','')or nil
   if name and#name>0 and not name:find('/',1,true)then items[#items+1]={name=name,kind=FS:directoryExists(prefix..name)and'directory'or'file'}end
  end
  respond(c,'200 OK',{entries=items})
 elseif endpoint=='/file'and method=='GET'then
  if not FS:fileExists(full)then respond(c,'404 Not Found',{error='NotFoundError'});return end
  c.file=assert(io.open(full,'rb'));local size=c.file:seek('end');assert(size<=80*1024*1024,'Character file too large.');c.file:seek('set')
  respond(c,'200 OK','', 'application/octet-stream',size);c.readingFile=true
 elseif(endpoint=='/file'or c.preference)and method=='PUT'then
  for _,other in ipairs(clients)do assert(other==c or not other.upload,'Another character upload is in progress.')end
  local length=tonumber(h['content-length']);assert(length and length>=0 and length<=80*1024*1024 and length==math.floor(length)and not h['transfer-encoding'],'Invalid upload size.')
  quota(path,length)
  local temp='/temp/hotw/hub-transfer/';FS:directoryCreate(temp,true)
  c.temp=temp..Engine.generateUUID():gsub('[^a-zA-Z0-9]','')..'.tmp';c.path=full;c.remaining=length
  c.file=assert(io.open(c.temp,'wb'));c.upload=true
 elseif(endpoint=='/file'or endpoint=='/directory')and method=='DELETE'then
  assert(path~=''and path~='characters'and path~='hub-transactions','Root deletion rejected.')
  if isDirectory then
   -- Only the character/transaction roots owned by this session's catalog may recurse.
   assert(path:match('^characters/[^/]+$')or path:match('^hub%-transactions/[^/]+$')or not uri:find('recursive=1',1,true),'Recursive directory rejected.')
   if FS:directoryExists(full)then assert(FS:directoryRemove(full)~=false,'Could not remove character directory.')end
  elseif FS:fileExists(full)then assert(FS:removeFile(full)~=false,'Could not remove character file.')end
  respond(c,'200 OK',{success=true})
 else respond(c,'404 Not Found',{error='Unknown operation.'})end
end
function M.start()
 if listener then return {success=true,url=website..'#port='..port..'&session='..token}end
 socket=require('socket.socket')
 local s=assert(socket.tcp());s:settimeout(0);assert(s:bind('127.0.0.1',0));assert(s:listen(8))
 local _,assigned=s:getsockname();port=assigned;listener=s
 origin='http://127.0.0.1:'..port;website=origin..'/hub/'
 token=hashStringSHA256(Engine.generateUUID()..Engine.generateUUID()):lower();lastRequest=socket.gettime()
 return {success=true,url=website..'#port='..port..'&session='..token}
end
-- Drain ready sockets in bounded slices instead of limiting every request/file
-- to one 64 KiB chunk per rendered frame. Never wait for socket readiness.
local function pump(c)
 if socket.gettime()-c.created>90 then c.finished=true;return false end
 local progressed=false
 if not c.responding then
  local data,err,partial=c.peer:receive(65536);data=data or partial or''
  if err=='closed'and#data==0 then c.finished=true;return false end
  if#data==0 then return false end
  progressed=true
  if not c.upload then c.buffer=c.buffer..data;headers(c)else c.buffer=data end
  if c.upload then
   assert(#c.buffer<=c.remaining,'Upload length mismatch.');assert(c.file:write(c.buffer));c.remaining=c.remaining-#c.buffer;c.buffer=''
   if c.addonPayload then updater.noteUpload(c.total-c.remaining,c.operation)end
   if c.remaining==0 then c.upload=false;finishWrite(c)end
  end
 end
 if c.responding then
  if c.sent>#c.output then
   if c.readingFile then c.output=c.file:read(65536)or'';c.sent=1;if#c.output==0 then c.finished=true;return true end
   else c.finished=true;return true end
  end
  local before=c.sent
  local n,err,last=c.peer:send(c.output,c.sent);c.sent=(n or last or(c.sent-1))+1
  if err=='closed'then c.finished=true end
  progressed=progressed or c.sent>before
 end
 return progressed
end
function M.step()
 updater.tick()
 if not listener then return end
 if socket.gettime()-lastRequest>1800 then M.stop();return end
 for _=1,8 do
  local peer=listener:accept();if not peer then break end
  peer:settimeout(0)
  if#clients<8 then clients[#clients+1]={peer=peer,buffer='',created=socket.gettime()}else peer:close()end
 end
 local deadline=socket.gettime()+.0025
 for _=1,32 do
  local progressed=false
  for _,c in ipairs(clients)do
   if not c.finished and socket.gettime()<deadline then
    local ok,result=pcall(pump,c)
    if not ok then
     log('W','hotw.hubBridge',tostring(result))
     if c.responding then c.finished=true else
      if c.file then c.file:close();c.file=nil end
      respond(c,'403 Forbidden',{error='The game rejected this Hub request.'})
     end
    end
    progressed=progressed or result==true or not ok
   end
  end
  if not progressed or socket.gettime()>=deadline then break end
 end
 local live={}
 for _,c in ipairs(clients)do if c.finished then cleanup(c)else live[#live+1]=c end end
 clients=live
end
M.allowed=allowed
return M
