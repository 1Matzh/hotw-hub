-- Hands on the Wheel (HOTW)
-- Copyright (c) 2026 1Matzh. All rights reserved.
-- Written permission from 1Matzh is required. See LICENSE or hotw/code-license.txt.
-- Own-addon updater: only publisher-signed metadata can authorize a ZIP replacement.
local M={}
local signature=require('hotw/hubSignature')
local updateRoot='https://raw.githubusercontent.com/1Matzh/hotw-hub/main/addon-updates/'
local marker='/hotw/hub/addon.json'
local mounted=jsonReadFile(marker)or{}
local current=mounted.version or'0.0.0'
local pendingPath='/hotw/hub-addon-update.json'
local state={state='idle',currentVersion=current,downloaded=0,total=0}
local verified
local temporary
local pendingInstall
local function version(value)
 if type(value)~='string'then return end
 local a,b,c=value:match('^v?(%d+)%.(%d+)%.(%d+)$')
 if not a or#a>6 or#b>6 or#c>6 then return end
 for _,part in ipairs({a,b,c})do if#part>1 and part:sub(1,1)=='0'then return end end
 return{tonumber(a),tonumber(b),tonumber(c)}
end
local function newer(a,b)
 a,b=version(a),version(b);if not a or not b then return false end
 for i=1,3 do if a[i]~=b[i]then return a[i]>b[i]end end
 return false
end
local function active()return state.state=='checking'or state.state=='downloading'or state.state=='verifying'or state.state=='installing'end
local function failure(message,detail)
 state.state='error';state.error=message or'Addon update failed. Your previous addon has been preserved.'
 state.diagnostic=detail and tostring(detail)or nil
 if detail and log then log('W','hotw.hubUpdater',tostring(detail))end
end
local function fileBytes(path)
 local f=assert(io.open(path,'rb'),'Update file is missing');local size=assert(f:seek('end'));assert(size<=16*1024*1024,'Update file is too large');f:seek('set')
 local bytes=f:read('*a');f:close();assert(type(bytes)=='string'and#bytes==size,'Update file is incomplete');return bytes
end
local function descriptor(data)
 assert(type(data)=='table'and data.schema==1 and data.repository=='1Matzh/hotw-hub','Invalid addon repository')
 assert(version(data.version),'Invalid addon version')
 local name='hotw-hub-addon-'..data.version..'.zip'
 assert(data.name==name and data.url==updateRoot..name,'Invalid addon download URL')
 assert(type(data.size)=='number'and data.size>0 and data.size<=16*1024*1024 and data.size==math.floor(data.size),'Invalid addon size')
 assert(type(data.sha256)=='string'and#data.sha256==64 and data.sha256:match('^[0-9a-f]+$'),'Missing addon SHA-256 digest')
 return data
end
local function archivePath()
 assert(core_modmanager and core_modmanager.getModForFilename,'Mod manager unavailable')
 local _,mod=core_modmanager.getModForFilename(marker)
 if not mod or mod.unpackedPath or type(mod.fullpath)~='string'then error('ZIP_REQUIRED')end
 local path=mod.fullpath
 assert(path:match('^/mods/[a-zA-Z0-9_./%-]+%.zip$')and not path:find('..',1,true)and not path:find('//',1,true),'Invalid addon archive path')
 assert(mod.mountPoint==nil or mod.mountPoint=='','Unexpected addon mount point')
 return path
end
local function inspectZip(path,expected)
 local zip=ZipArchive();assert(zip:openArchiveName(path,'r'),'Invalid addon ZIP')
 local ok,result=pcall(function()
  local found,count={},0
  for index,name in pairs(zip:getFileList()or{})do
   -- BeamNG's ZIP API prefixes entries with the virtual filesystem root.
   if type(name)=='string'and name:sub(1,1)=='/'then name=name:sub(2)end
   assert(type(name)=='string'and not name:find('..',1,true)and not name:find('\\',1,true)and not name:find('//',1,true)and name:sub(1,1)~='/','Invalid addon ZIP path')
   if name:sub(-1)~='/'then
    count=count+1;assert(count<=256 and not found[name:lower()],'Duplicate or excessive addon entries');found[name:lower()]=true
    assert(name:match('^hotw/hub/[a-zA-Z0-9_./%-]+$')or name:match('^lua/common/hotw/hub[a-zA-Z0-9_]*%.lua$')or name=='mod_info/hotw-hub/info.json','ZIP contains files outside the addon')
    if name==marker:sub(2)or name=='mod_info/hotw-hub/info.json'then
     local bytes=assert(zip:readFileEntryByIdx(index));assert(#bytes<65536,'Oversized addon metadata');found[name]=assert(jsonDecode(bytes))
    end
   end
  end
  local info=found[marker:sub(2)];assert(type(info)=='table'and info.id=='hotw-hub'and info.schema==1 and info.protocol==1 and info.skeleton=='hotw-humanoid-v4'and info.version==expected,'Addon metadata differs from release')
  assert(found['lua/common/hotw/hubaddon.lua']and found['lua/common/hotw/hubbridge.lua']and found['hotw/hub/index.html'],'Incomplete addon ZIP')
  assert(type(found['mod_info/hotw-hub/info.json'])=='table'and found['mod_info/hotw-hub/info.json'].version==expected,'Addon version metadata differs')
  local base=jsonReadFile('/mod_info/handsonthewheel/info.json')or{}
  assert(version(base.version),'Could not verify HOTW version')
  assert(not info.minimumHotwVersion or(version(info.minimumHotwVersion)and not newer(info.minimumHotwVersion,base.version)),'CORE_UPDATE_REQUIRED')
  return info
 end)
 zip:close();assert(ok,result);return result
end
local function install(path,release)
 local target=archivePath();local bytes=fileBytes(path)
 assert(#bytes==release.size,'Addon size mismatch')
 assert(hashStringSHA256(bytes):lower()==release.sha256,'Addon SHA-256 mismatch')
 inspectZip(path,release.version)
 -- Only this addon's mounted ZIP can be replaced. Keep a unique rollback file
 -- outside /mods so the engine never discovers it as another active addon.
 local rollbackRoot='/hotw/hub-update-backups/';assert(FS:directoryCreate(rollbackRoot,true)~=false)
 local rollback=rollbackRoot..Engine.generateUUID():gsub('[^a-zA-Z0-9]','')..'.zip'
 local wasMounted=FS:isMounted(target);local moved=false
 state.state='installing'
 local ok,err=pcall(function()
  if wasMounted then FS:unmount(target);assert(not FS:isMounted(target),'Could not release addon archive')end
  assert(FS:renameFile(target,rollback)==0,'Could not preserve previous addon');moved=true
  assert(FS:renameFile(path,target)==0,'Could not replace addon archive')
  assert(hashStringSHA256(fileBytes(target)):lower()==release.sha256,'Installed addon hash mismatch')
  if wasMounted then assert(FS:mountList({{srcPath=target,mountPath=''}}),'Could not remount updated addon')end
 end)
 if not ok then
  if moved then
   if FS:isMounted(target)then FS:unmount(target)end
   if FS:fileExists(target)then FS:removeFile(target)end
   local restored=FS:renameFile(rollback,target)==0
   if wasMounted and restored then FS:mountList({{srcPath=target,mountPath=''}})end
   assert(restored,'Previous addon recovery failed; rollback preserved at '..rollback)
  elseif wasMounted and not FS:isMounted(target)then FS:mountList({{srcPath=target,mountPath=''}})end
  error(err)
 end
 temporary=nil
 state.state='restart';state.version=release.version;state.downloaded=release.size;state.total=release.size;state.restartRequired=true
 if jsonWriteFile(pendingPath,{schema=1,version=release.version,archive=target,sha256=release.sha256,backup=rollback},true)==false and type(log)=='function'then log('W','hotw.hubUpdater','Updated addon installed; restart reminder could not be saved')end
end
local function sameOperation(operation,phase)
 assert(type(operation)=='string'and operation==state.operation and state.state==phase,'Inactive addon update operation')
end
function M.start()
 if active()or state.restartRequired then return M.status()end
 pendingInstall=nil;verified=nil
 if temporary and FS:fileExists(temporary)then FS:removeFile(temporary)end;temporary=nil
 state={state='checking',currentVersion=current,downloaded=0,total=0,started=os.time(),operation=Engine.generateUUID():gsub('[^a-zA-Z0-9]','')}
 local ok,err=pcall(archivePath)
 if not ok then failure(tostring(err):find('ZIP_REQUIRED',1,true)and'Install the HOTW Hub addon as a ZIP to enable automatic updates.'or nil,err)end
 return M.status()
end
function M.acceptManifest(bytes,operation)
 sameOperation(operation,'checking')
 local ok,err=pcall(function()
  assert(type(bytes)=='string'and#bytes<=16384,'Invalid addon update manifest')
  local envelope=jsonDecode(bytes)
  assert(type(envelope)=='table'and type(envelope.manifest)=='string'and#envelope.manifest<=8192,'Invalid signed manifest')
  assert(signature.verify(envelope.manifest,envelope.signature,jsonReadFile('/hotw/hub/update-key.json')),'Addon signature verification failed')
  local release=descriptor(jsonDecode(envelope.manifest))
  if not newer(release.version,current)then state.state='current';return end
  verified=release;state.state='downloading';state.version=release.version;state.total=release.size;state.url=release.url;state.sha256=release.sha256
 end)
 if not ok then failure(nil,err);error(err)end
 return M.status()
end
function M.uploadPath(length,operation)
 sameOperation(operation,'downloading')
 assert(verified and not temporary and length==verified.size,'Invalid addon payload size or duplicate transfer')
 local folder='/temp/hotw/addon-update/';assert(FS:directoryCreate(folder,true)~=false)
 temporary=folder..Engine.generateUUID():gsub('[^a-zA-Z0-9]','')..'.zip'
 return temporary
end
function M.noteUpload(amount,operation)
 sameOperation(operation,'downloading');assert(amount>=0 and amount<=state.total,'Invalid addon transfer progress');state.downloaded=amount
end
function M.completePayload(path,operation)
 sameOperation(operation,'downloading');assert(path==temporary and verified,'Unexpected addon payload')
 state.state='verifying';pendingInstall={path=path,release=verified}
 -- Do not install until this request has released its temporary file handle.
 local copy={};for k,v in pairs(state)do if k~='started'then copy[k]=v end end;return copy
end
function M.abortUpload(operation)
 if operation==state.operation and(state.state=='checking'or state.state=='downloading')then failure(nil,'Addon transfer interrupted')end
 return M.status()
end
function M.tick()
 if active()and os.time()-(state.started or 0)>180 then pendingInstall=nil;failure(nil,'Addon update timed out');return end
 if pendingInstall and state.state=='verifying'then
  local item=pendingInstall;pendingInstall=nil
  local ok,err=pcall(install,item.path,item.release)
  if not ok then failure(tostring(err):find('CORE_UPDATE_REQUIRED',1,true)and'Update Hands on the Wheel before installing this addon version.'or nil,err)end
 end
end
function M.status()
 M.tick();local copy={};for k,v in pairs(state)do if k~='started'then copy[k]=v end end;return copy
end
-- Persist the restart reminder when the browser reconnects, but clear it when
-- the newly installed version is running after the next game start.
local pending=jsonReadFile(pendingPath)
if type(pending)=='table'and pending.schema==1 and version(pending.version)then
 if newer(pending.version,current)then state.state='restart';state.version=pending.version;state.restartRequired=true
 else FS:removeFile(pendingPath)end
end
M.newer=newer
M.descriptor=descriptor
return M
